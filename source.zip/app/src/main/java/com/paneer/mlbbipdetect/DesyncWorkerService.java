package com.paneer.mlbbipdetect;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

public class DesyncWorkerService extends Service {

    public static final String ACTION_START = "com.paneer.mlbbipdetect.START_DESYNC";
    public static final String ACTION_STOP = "com.paneer.mlbbipdetect.STOP_DESYNC";
    public static final String EXTRA_IP = "ip";
    public static final String EXTRA_PORT = "port";
    public static final String EXTRA_THREADS = "threads";
    public static final String EXTRA_SIZE = "size";
    public static final String EXTRA_MODE = "mode";
    public static final String EXTRA_INTENSITY = "intensity";
    public static final String BROADCAST_DESYNC = "com.paneer.mlbbipdetect.DESYNC_STATUS";

    private static final String CHANNEL_ID = "mlbb_desync";
    private static final int NOTIF_ID = 1003;

    public static final DesyncEngine ENGINE = new DesyncEngine();

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_START.equals(action)) {
            String ip = intent.getStringExtra(EXTRA_IP);
            int port = intent.getIntExtra(EXTRA_PORT, 5000);
            int threads = intent.getIntExtra(EXTRA_THREADS, 10);
            int size = intent.getIntExtra(EXTRA_SIZE, 512);
            String modeStr = intent.getStringExtra(EXTRA_MODE);
            int intensity = intent.getIntExtra(EXTRA_INTENSITY, 6);
            DesyncEngine.Mode mode = DesyncEngine.Mode.JITTER;
            try {
                if (modeStr != null) mode = DesyncEngine.Mode.valueOf(modeStr);
            } catch (Exception ignored) {}
            startDesync(ip, port, threads, size, mode, intensity);
        } else if (ACTION_STOP.equals(action)) {
            stopDesync();
            stopSelf();
        }
        return START_STICKY;
    }

    private void startDesync(String ip, int port, int threads, int size,
                             DesyncEngine.Mode mode, int intensity) {
        createChannel();
        startForeground(NOTIF_ID, buildNotif("Desync " + mode.name() + " → " + ip + ":" + port));

        ENGINE.setListener(new DesyncEngine.Listener() {
            @Override
            public void onStats(long packets, long bytes, int threads, String mode) {
                Intent i = new Intent(BROADCAST_DESYNC);
                i.putExtra("status", "RUNNING");
                i.putExtra("packets", packets);
                i.putExtra("bytes", bytes);
                i.putExtra("threads", threads);
                i.putExtra("mode", mode);
                i.setPackage(getPackageName());
                sendBroadcast(i);
            }

            @Override
            public void onError(String msg) {
                Intent i = new Intent(BROADCAST_DESYNC);
                i.putExtra("status", "ERROR");
                i.putExtra("msg", msg);
                i.setPackage(getPackageName());
                sendBroadcast(i);
            }

            @Override
            public void onStopped() {
                Intent i = new Intent(BROADCAST_DESYNC);
                i.putExtra("status", "STOPPED");
                i.setPackage(getPackageName());
                sendBroadcast(i);
            }
        });

        ENGINE.start(ip, port, threads, size, mode, intensity);
    }

    private void stopDesync() {
        ENGINE.stop();
        stopForeground(true);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Desync / Bot Match", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotif(String text) {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("MLBB Desync Active")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_rotate)
                .setOngoing(true)
                .build();
    }

    @Override
    public void onDestroy() {
        ENGINE.stop();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
