package com.paneer.mlbbipdetect;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Thread-safe store of observed remote endpoints from VPN capture.
 * Filters to MLBB-relevant port ranges and ranks by packet volume.
 */
public final class IpStore {

    // MLBB observed port ranges (from public port lists)
    private static final int[][] MLBB_UDP_RANGES = {
            {2702, 2702}, {3702, 3702}, {4001, 4009},
            {5000, 5221}, {5224, 5241}, {5243, 5287}, {5289, 5352},
            {5354, 5509}, {5507, 5507}, {5517, 5529},
            {5551, 5569}, {5601, 5700},
            {8001, 8001}, {8130, 8130},
            {9000, 9010}, {9120, 9120}, {9992, 9992},
            {10003, 10003}, {30000, 30900}
    };

    private static final int[][] MLBB_TCP_RANGES = {
            {5000, 5221}, {5224, 5227}, {5229, 5241}, {5243, 5287},
            {5289, 5352}, {5354, 5509}, {5517, 5517}, {5520, 5529},
            {5551, 5569}, {5601, 5700},
            {9000, 9010}, {9443, 9443}, {10003, 10003},
            {30000, 30900}
    };

    private final ConcurrentHashMap<String, IpEntry> map = new ConcurrentHashMap<>();

    public void record(String ip, int port, boolean isUdp, int payloadLen) {
        if (ip == null || ip.isEmpty()) return;
        // skip private / link-local / loopback
        if (isPrivate(ip)) return;
        if (!isMlbbPort(port, isUdp)) return;

        String key = ip + ":" + port;
        IpEntry e = map.computeIfAbsent(key, k -> new IpEntry(ip, port, isUdp));
        e.hit(payloadLen);

        // candidate heuristic: sustained UDP traffic on game ports
        if (isUdp && e.packetCount.get() >= 8) {
            e.isCandidate = true;
        }
    }

    public List<IpEntry> getSorted() {
        List<IpEntry> list = new ArrayList<>(map.values());
        Collections.sort(list, Comparator
                .comparingLong((IpEntry e) -> e.packetCount.get()).reversed()
                .thenComparingLong(e -> e.byteCount.get()).reversed());
        return list;
    }

    public List<IpEntry> getCandidates() {
        List<IpEntry> out = new ArrayList<>();
        for (IpEntry e : map.values()) {
            if (e.isCandidate) out.add(e);
        }
        Collections.sort(out, Comparator.comparingLong((IpEntry e) -> e.packetCount.get()).reversed());
        return out;
    }

    public void clear() {
        map.clear();
    }

    public int size() {
        return map.size();
    }

    private static boolean isPrivate(String ip) {
        return ip.startsWith("10.")
                || ip.startsWith("192.168.")
                || ip.startsWith("127.")
                || ip.startsWith("0.")
                || ip.startsWith("169.254.")
                || ip.startsWith("::")
                || ip.equals("0.0.0.0");
    }

    private static boolean isMlbbPort(int port, boolean udp) {
        int[][] ranges = udp ? MLBB_UDP_RANGES : MLBB_TCP_RANGES;
        for (int[] r : ranges) {
            if (port >= r[0] && port <= r[1]) return true;
        }
        // also accept common high ports used by game backends
        return port >= 10000 && port <= 11000;
    }
}
